﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SlimDX;
using SlimDX.D3DCompiler;
using SlimDX.Direct3D11;
using SlimDX.DXGI;
using SlimDX.Windows;
using Device = SlimDX.Direct3D11.Device;
using Resource = SlimDX.Direct3D11.Resource;

namespace SimpleTriangle.World
{
    /// <summary>
    /// Représente une cellule du QuadTree formant les parcelles de terrains de la planète.
    /// </summary>
    public class PlanetCell
    {
        #region Constants
        /// <summary>
        /// Résolution de la grille.
        /// </summary>
        public const int GridResolution = 32;
        #endregion

        #region Variables
        /// <summary>
        /// Indique si la région actuelle est subdivisée en morceaux de taille inférieure ou non.
        /// </summary>
        bool m_isSubdivided;
        /// <summary>
        /// Cellules intérieures.
        /// Les données contenues dans ces cellules sont valides si m_isSubdivided vaut true.
        /// Sinon, elles doivent être supprimées.
        /// </summary>
        PlanetCell[] m_subCells;
        /// <summary>
        /// Facteur d'échelle de cette cellule.
        /// Ce facteur est divisé par deux à chaque étage du quadtree.
        /// </summary>
        float m_scale;
        /// <summary>
        /// Graine de la planète.
        /// </summary>
        int m_seed;
        /// <summary>
        /// Facteur d'échelle globale du quadtree.
        /// Il est passé à l'identique de cellule en cellule.
        /// </summary>
        Vector3 m_globalScale;
        /// <summary>
        /// Position du coin supérieur gauche de la cellule sur la grille unitaire.
        /// </summary>
        Vector2 m_gridPosition;
        /// <summary>
        /// Position du centre de la planète.
        /// </summary>
        Vector3 m_planetPosition;
        /// <summary>
        /// Profondeur de la cellule dans le quadtree.
        /// </summary>
        int m_depth;

        /// <summary>
        /// Indique si la cellule est en cours d'expansion (le thread de création des cellules filles est toujours en cours).
        /// </summary>
        bool m_isExpanding;
        /// <summary>
        /// Indique si la cellule est toujours en cours de rétractation.
        /// </summary>
        bool m_isRetracting;
        /// <summary>
        /// Indique si la cellule est prête à être affichée.
        /// </summary>
        bool m_isReady;
        /// <summary>
        /// Tâche de génération de la planète.
        /// </summary>
        PlanetCellGenerationTask m_genTask;

        #region Variables graphiques
        SlimDX.Direct3D11.Buffer m_vertexBuffer;
        SlimDX.Direct3D11.Buffer m_indexBuffer;
        BoundingBox m_boundingBox;
        Matrix m_world;
        Graphics.Material m_material;
        #endregion

        #endregion

        #region Properties
        /// <summary>
        /// Obtient la matrice de transformation subie par cette cellule.
        /// </summary>
        public Matrix Transform
        {
            get { return m_world; }
        }
        /// <summary>
        /// Retourne la box représentant les bords de cette cellule.
        /// </summary>
        public BoundingBox Bounds
        {
            get { return m_boundingBox; }
        }
        /// <summary>
        /// Indique si la cellule est prête à être affichée.
        /// </summary>
        public bool IsReady
        {
            get { return m_isReady; }
        }
        #endregion

        #region Methods
        /// <summary>
        /// Crée une nouvelle instance de PlanetCell.
        /// </summary>
        public PlanetCell(Vector3 planetPosition, Vector2 gridPosition, float scale, Vector3 globalScale, int mSeed, bool skipBufferGen, int depth)
        {
            m_subCells = new PlanetCell[4];
            m_gridPosition = gridPosition;
            m_globalScale = globalScale;
            m_planetPosition = planetPosition;
            m_scale = scale;
            m_seed = mSeed;
            m_world = ComputeTransform();
            m_depth = depth;
            m_boundingBox = Util.MathHelper.Transform(m_world, new BoundingBox(new Vector3(0, 0, 0), new Vector3(1, 1, 1)));
            m_genTask = new PlanetCellGenerationTask();
            m_isReady = false;

            InitializeEffect();
            if(!skipBufferGen)
                CreateBuffers();
        }

        /// <summary>
        /// Initialise les paramètres du shader.
        /// </summary>
        void InitializeEffect()
        {
            m_material = new Graphics.Material(
                new Color4(1.0f, 0.48f, 0.48f, 0.48f), // ambient
                new Color4(1.0f, 0.68f, 0.68f, 0.68f), // diffuse
                new Color4(32.0f, 0.8f, 0.8f, 0.8f),
                //new Color4(2.0f, 0.2f, 0.2f, 0.2f), // specular
                new Color4(0, 0, 0, 0));
            
        }
        #region Expansion Mechanisms
        /// <summary>
        /// Subdivise cette cellule en quatre autres cellules de taille inférieure et de même résolution.
        /// Supprime aussi les données d'affichage de cette cellule (vertex / index buffers).
        /// </summary>
        public void Expand(int depth=0)
        {
            CreateSubCells(depth != 0);
            m_isExpanding = true;
            /*
            if(depth > 0)
            {
                // TODO : faire en sorte de skip la création du buffer sur les cellules filles.
                foreach(PlanetCell cell in m_subCells)
                {
                    cell.Expand(depth - 1);
                }
            }*/
        }

        /// <summary>
        /// Initialise les cellules de l'étage inférieur du quadtree.
        /// </summary>
        void CreateSubCells(bool skipBufferGeneration=false)
        {
            float newScale = m_scale / 2;
            for(int i = 0; i < 4; i++)
            {
                int x = i % 2;
                int y = i / 2;
                Vector2 cellPos = new Vector2(m_gridPosition.X + x * newScale, m_gridPosition.Y + y * newScale);
                PlanetCell newCell = new PlanetCell(m_planetPosition, cellPos, newScale, m_globalScale, m_seed, skipBufferGeneration, m_depth+1);
                m_subCells[i] = newCell;
            }
        }

        /// <summary>
        /// Supprime les cellules contenues dans cette cellule, et recrée les données d'affichage de celle-ci.
        /// </summary>
        public void Retract()
        {
            CreateBuffers();
            m_isRetracting = true;


        }
        #endregion


        #region Buffer creation
        /// <summary>
        /// Crée les index et vertex buffers.
        /// </summary>
        public void CreateBuffers()
        {
          
            // Heightmap
            // Initialisation des paramètres du bruit
            Noise.NoiseMapGenerator.NoiseParameters m_repartitionNoise;
            Noise.NoiseMapGenerator.NoiseParameters m_noiseHigh;
            Noise.NoiseMapGenerator.NoiseParameters m_noiseLow;

            m_repartitionNoise = new Noise.NoiseMapGenerator.NoiseParameters();
            m_noiseHigh = new Noise.NoiseMapGenerator.NoiseParameters();
            m_noiseLow = new Noise.NoiseMapGenerator.NoiseParameters();

            m_noiseHigh.NoiseType = Noise.NoiseMapGenerator.NoiseParameters.RIDGED_ID;
            m_noiseHigh.OctaveCount = 4;
            m_noiseHigh.Lacunarity = 1.8f;
            m_noiseHigh.Frequency = 6;
            m_noiseHigh.Persistence = 0.94f;
            m_noiseHigh.Seed = 1073741824;

            m_repartitionNoise.NoiseType = Noise.NoiseMapGenerator.NoiseParameters.RIDGED_ID;
            m_repartitionNoise.OctaveCount = 5;
            m_repartitionNoise.Persistence = 0.91f;
            m_repartitionNoise.Frequency = 64;
            m_repartitionNoise.Lacunarity = 3.6f;
            m_repartitionNoise.Seed = 1254546457;
            m_repartitionNoise.NoiseStart = m_gridPosition;
            m_repartitionNoise.NoiseEnd = m_gridPosition + new Vector2(1, 1) * m_scale;

            m_noiseLow.NoiseType = Noise.NoiseMapGenerator.NoiseParameters.PERLIN_ID;
            m_noiseLow.Frequency = 32;
            m_noiseLow.Lacunarity = 1.4f;
            m_noiseLow.Persistence = 0.237f;
            m_noiseLow.OctaveCount = 4;
            m_noiseLow.Seed = 1073741824;

            /*float[,] heightmap = Noise.NoiseMapGenerator.GenerateMultiNoiseParallel(16, m_repartitionNoise, m_noiseHigh, m_noiseLow);

            InputElement[] elems;
            Generation.ModelGenerator.GenerateVertexBuffer(heightmap, out m_vertexBuffer, out m_indexBuffer, out elems);*/
            m_genTask.RunCalculation(32, m_noiseLow, m_noiseHigh, m_repartitionNoise, m_world);
            m_isReady = false;
           /* m_inLayout = new InputLayout(
                Scene.GetGraphicsDevice(), m_effect.GetTechniqueByIndex(0).GetPassByIndex(0).Description.Signature, elems);*/
        }
        /// <summary>
        /// Supprime les buffers de cette cellule.
        /// </summary>
        public void DisposeBuffers()
        {
            if (m_indexBuffer != null)
            {
                m_indexBuffer.Dispose();
                m_vertexBuffer.Dispose();
            }
        }
        #endregion

        #region Update / Draw
        /// <summary>
        /// Mise à jour de la cellule.
        /// </summary>
        public void Update()
        {
            if (m_isReady)
            {
                BoundingBox bounds = Bounds;
                Vector2 position = new Vector2(Scene.Instance.Camera.Position.X, Scene.Instance.Camera.Position.Y);
                Vector2 center = new Vector2(bounds.Minimum.X + bounds.Maximum.X, bounds.Minimum.Y + bounds.Maximum.Y) / 2;
                float diagLength = Vector2.Distance(Util.MathHelper.ReduceXY(bounds.Minimum), Util.MathHelper.ReduceXY(bounds.Maximum));
                float distance = Vector2.Distance(position, center);
                float factor = 1+  Math.Max(0, 5 - m_depth);
                if (m_isSubdivided)
                {
                    // Si la cellule est divisée et qu'on s'éloigne trop : on la rétracte.
                    if (distance > diagLength * 1.8f * factor && !m_isRetracting)
                    {
                        Retract();
                    }
                }
                else
                {
                    // Si la cellule n'est pas subdivisée et qu'on y rentre, alors on la divise.
                    if (m_depth < 10 && !m_isExpanding && distance < diagLength * 1.2f * factor)
                    {
                        Expand(0);
                    }
                }
                // Si enfants : 
                if (m_isSubdivided || m_isExpanding)
                {
                    foreach (PlanetCell cell in m_subCells)
                    {
                        cell.Update();
                    }
                }
            }
            else
            {
                // Si la cellule n'est pas prête, on attend la réception des buffers.
                if(m_genTask.IsRessourceReady)
                {
                    var rsc = m_genTask.Ressource;
                    m_vertexBuffer = rsc.VertexBuffer;
                    m_indexBuffer = rsc.IndexBuffer;
                    m_isReady = true;
                }
            }

            // Gère la transition expansion.
            if (m_isExpanding)
            {
                bool childrenReady = true;
                foreach (PlanetCell cell in m_subCells)
                {
                    if (!cell.IsReady)
                    {
                        childrenReady = false;
                        break;
                    }
                }

                if (childrenReady)
                {
                    DisposeBuffers();
                    m_isSubdivided = true;
                    m_isExpanding = false;
                }
            }

            // Gère la transition de rétractation.
            if (m_isRetracting)
            {
                if (m_genTask.IsRessourceReady)
                {
                    var rsc = m_genTask.Ressource;
                    m_vertexBuffer = rsc.VertexBuffer;
                    m_indexBuffer = rsc.IndexBuffer;

                    m_isSubdivided = false;
                    foreach (PlanetCell cell in m_subCells)
                    {
                        cell.Dispose();
                    }
                    m_isRetracting = false;
                    m_isReady = true;
                }
            }
        }
        /// <summary>
        /// Dessine cette cellule.
        /// </summary>
        public void Draw()
        {
            if(m_isSubdivided)
            {
                foreach(PlanetCell cell in m_subCells)
                {
                    cell.Draw();
                }
            }
            else if(m_isReady)
            {
                // Dessine la cellule.
                var device = Scene.GetGraphicsDevice().ImmediateContext;
                device.InputAssembler.SetIndexBuffer(m_indexBuffer, Format.R32_UInt, 0);
                device.InputAssembler.PrimitiveTopology = (PrimitiveTopology.TriangleList);
                device.InputAssembler.SetVertexBuffers(0, new VertexBufferBinding(m_vertexBuffer, Graphics.VertexPositionTextureNormal.Vertex.Stride, 0));

                RasterizerStateDescription rsd = new RasterizerStateDescription()
                {
                    CullMode = CullMode.None,
                    DepthBias = 0,
                    DepthBiasClamp = 0.0f,
                    FillMode = FillMode.Solid,
                    IsAntialiasedLineEnabled = true,
                    IsDepthClipEnabled = true,
                    IsFrontCounterclockwise = false,
                    IsMultisampleEnabled = false,
                    IsScissorEnabled = false,
                    SlopeScaledDepthBias = 0.0f
                };
                RasterizerState rs = RasterizerState.FromDescription(Scene.GetGraphicsDevice(), rsd);
                device.Rasterizer.State = rs;

                // Variables
                Graphics.BasicEffect effect = Scene.GetGraphicsEngine().BasicEffect;
                effect.Apply(Matrix.Identity, Scene.Instance.Camera.View, Scene.Instance.Camera.Projection, m_material);
                device.DrawIndexed(m_indexBuffer.Description.SizeInBytes / sizeof(int), 0, 0);
                /*m_worldVariable.AsMatrix().SetMatrix(Matrix.Identity);
                m_viewVariable.AsMatrix().SetMatrix(Scene.Instance.Camera.View);
                m_projectionVariable.AsMatrix().SetMatrix(Scene.Instance.Camera.Projection);
                m_cameraPositionVariable.AsVector().Set(Scene.Instance.Camera.Position);
                m_textureVariable.AsResource().SetResource(Ressources.ShaderRessourceViewCache.Get("Textures\\tex_3.jpg"));
                m_effect.GetVariableByName("xTextureRock").AsResource().SetResource(Ressources.ShaderRessourceViewCache.Get("Textures\\tex_2.jpg"));
                // Dessin
                for (int i = 0; i < m_effect.GetTechniqueByIndex(0).Description.PassCount; i++)
                {
                    m_effect.GetTechniqueByIndex(0).GetPassByIndex(i).Apply(device);
                    device.DrawIndexed(m_indexBuffer.Description.SizeInBytes / sizeof(int), 0, 0);
                }*/

                /*// Bounding box
                Debug.Renderers.BoundingBoxRenderer.Render(Bounds,
                    Scene.GetGraphicsDevice(),
                    Matrix.Identity,
                    Scene.Instance.Camera.View,
                    Scene.Instance.Camera.Projection,
                    new Color4(255, 0, 0, 255));*/
            }


        }
        #endregion

        
        #region Dispose
        /// <summary>
        /// Supprime les ressources allouées par cette cellule.
        /// </summary>
        public void Dispose()
        {
            DisposeBuffers();
        }
        #endregion

        #region Utils
        /// <summary>
        /// Calcule et retourne la matrice de transformation subie par cette cellule.
        /// </summary>
        /// <returns></returns>
        public Matrix ComputeTransform()
        {
            Matrix scaling = Matrix.Scaling(m_globalScale.X * m_scale, m_globalScale.Y * m_scale, m_globalScale.Z);
            Vector3 position = new Vector3((m_gridPosition - new Vector2(0.5f, 0.5f)), 0);
            position.X *= m_globalScale.X; position.Y *= m_globalScale.Y; position.Z *= m_globalScale.Z;
            position += m_planetPosition;

            Matrix world = scaling * Matrix.Translation(position);
            return world;
        }
        #endregion
        #endregion
    }
}
