﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SlimDX;
using SlimDX.D3DCompiler;
using SlimDX.Direct3D11;
using SlimDX.DXGI;
using SlimDX.Windows;
using Device = SlimDX.Direct3D11.Device;
using Resource = SlimDX.Direct3D11.Resource;
namespace SimpleTriangle
{
    /// <summary>
    /// Représente la scène qui sera exécutée.
    /// </summary>
    public class Scene
    {
        /* ---------------------------------------------------------------------------------
         * Static
         * -------------------------------------------------------------------------------*/
        #region Static
        /// <summary>
        /// Représente l'instance en cours d'exécution de la Scène.
        /// </summary>
        public static Scene Instance;
        public static World.Graphics.Engine GetGraphicsEngine() { return Instance.GraphicsEngine; }
        public static Device GetGraphicsDevice() { return Instance.GraphicsEngine.GraphicsDevice; }
        public int ResolutionWidth = 800;
        public int ResolutionHeight = 600;
        #endregion
        /* ---------------------------------------------------------------------------------
         * Variables
         * -------------------------------------------------------------------------------*/
        #region Variables
        World.Graphics.Engine m_graphicsEngine;
        World.Planet m_landscape;
        World.Cameras.FirstPersonCamera m_camera;
        #endregion

        /* ---------------------------------------------------------------------------------
         * Properties
         * -------------------------------------------------------------------------------*/
        #region Properties
        /// <summary>
        /// Obtient une référence vers le moteur graphique.
        /// </summary>
        public World.Graphics.Engine GraphicsEngine
        {
            get { return m_graphicsEngine; }
            private set { m_graphicsEngine = value; }
        }

        /// <summary>
        /// Obtient une référence vers l'objet représentant la planète.
        /// </summary>
        public World.Planet Planet
        {
            get { return m_landscape; }
            set { m_landscape = value; }
        }

        /// <summary>
        /// Obtient une référence vers la caméra actuelle.
        /// </summary>
        public World.Cameras.FirstPersonCamera Camera
        {
            get { return m_camera; }
            private set { m_camera = value; }
        }
        #endregion
        /* ---------------------------------------------------------------------------------
         * Methods
         * -------------------------------------------------------------------------------*/
        #region Methods
        /// <summary>
        /// Crée l'instance unique de la scène.
        /// </summary>
        public Scene()
        {
            if (Instance != null)
                throw new InvalidOperationException();

            Instance = this;
            GraphicsEngine = new World.Graphics.Engine();
            
            Planet = new World.Planet();
            Camera = new World.Cameras.FirstPersonCamera();
            Camera.Position = new Vector3(4, 0, 0);

            // Positionnement des lumières.
            GraphicsEngine.LoadFX();
            GraphicsEngine.BasicEffect.DirLight = new World.Graphics.DirectionalLight()
            {
                Ambient = new Color4(0.2f, 0.2f, 0.2f),
                Diffuse = new Color4(0.8f, 0.8f, 0.8f),
                Specular = new Color4(0.5f, 0.5f, 0.5f),
                Direction = new Vector3(0.57735f, -0.57735f, 0.57735f)
                
            };
            GraphicsEngine.BasicEffect.PtLight = new World.Graphics.PointLight()
            {
                Ambient = new Color4(0.3f, 0.1f, 0.1f),
                Diffuse = new Color4(0.7f, 0.7f, 0.7f),
                Specular = new Color4(1f, 1f, 1f),
                Attenuation = new Vector3(0.000001f, 0.000001f, 0.000001f),
                Range = 100f,
                Position = new Vector3(10, 10, 100)
            };
            GraphicsEngine.BasicEffect.Texture = Ressources.ShaderRessourceViewCache.Get("Textures\\tex_3.jpg");
            GraphicsEngine.BasicEffect.Texture2 = Ressources.ShaderRessourceViewCache.Get("Textures\\tex_2.jpg");
            GraphicsEngine.BasicEffect.Texture3 = Ressources.ShaderRessourceViewCache.Get("Textures\\tex_1.jpg");

            Input.ModuleInit();
        }

        /// <summary>
        /// Mets à jour la caméra contrôlée par la souris.
        /// </summary>
        /// <param name="time"></param>
        void UpdateMouseCamera()
        {
            /*
            float angleSpeed = 30;
            // Angle de la caméra.
            float delta = Math.Min(0.1f, 0.1f);
            Vector2 mouse = Input.GetMousePos();
            int centerX = Scene.Instance.ResolutionWidth / 2;
            int centerY = Scene.Instance.ResolutionHeight / 2;
            float cameraRotationX = -Microsoft.Xna.Framework.MathHelper.ToRadians((mouse.X - centerX) * angleSpeed * 0.01f);
            float cameraRotationY = Microsoft.Xna.Framework.MathHelper.ToRadians((mouse.Y - centerY) * angleSpeed * 0.01f); 
            */
            if (Input.IsPressed(SlimDX.DirectInput.Key.LeftShift))
            {
                if (Input.IsPressed(SlimDX.DirectInput.Key.A))
                    Camera.RotateSide(0.01f);//cameraRotationX * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.S))
                    Camera.RotateUpDown(-0.01f); //-cameraRotationY * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.D))
                    Camera.RotateSide(-0.01f);//cameraRotationX * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.W))
                    Camera.RotateUpDown(0.01f); //-cameraRotationY * angleSpeed * delta);
            }
            else
            {
                float speed = 0.50f;
                if (Input.IsPressed(SlimDX.DirectInput.Key.Space))
                    speed *= 15;
                if (Input.IsPressed(SlimDX.DirectInput.Key.A))
                    Camera.MoveSide(speed);//cameraRotationX * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.S))
                    Camera.MoveForward(-speed); //-cameraRotationY * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.D))
                    Camera.MoveSide(-speed);//cameraRotationX * angleSpeed * delta);
                if (Input.IsPressed(SlimDX.DirectInput.Key.W))
                    Camera.MoveForward(speed); //-cameraRotationY * angleSpeed * delta);
            }
            GraphicsEngine.BasicEffect.PtLight = new World.Graphics.PointLight()
            {
                Ambient = new Color4(0.3f, 0.3f, 0.3f),
                Diffuse = new Color4(0.7f, 0.7f, 0.7f),
                Specular = new Color4(0.7f, 0.7f, 0.7f),
                Attenuation = new Vector3(0.1f, 0.01f, 0.0f),
                Range = 500f,
                Position = Camera.Position
            };
            GraphicsEngine.BasicEffect.EyePosition = Camera.Position;
            //GraphicsEngine.BasicEffect.PtLight.Position = Camera.Position;
        }
        
        /// <summary>
        /// Mets à jour les éléments de la scène.
        /// </summary>
        public void Update()
        {
            Input.Update();

            UpdateMouseCamera();

            Planet.Update();
        }


        /// <summary>
        /// Effectue le rendu de la scène.
        /// </summary>
        public void Draw()
        {
            Device device = GetGraphicsDevice();
            device.ImmediateContext.ClearRenderTargetView(GraphicsEngine.MainRenderTarget, new Color4(System.Drawing.Color.Black));
            device.ImmediateContext.ClearDepthStencilView(GraphicsEngine.MainStencilBuffer, DepthStencilClearFlags.Depth | DepthStencilClearFlags.Stencil, 1.0f, 0);
            Planet.Draw();
            GraphicsEngine.MainSwapChain.Present(0, PresentFlags.None);
        }

        /// <summary>
        /// Dispose les ressources non managées.
        /// </summary>
        public void Dispose()
        {
            GraphicsEngine.Dispose();
            Planet.Dispose();
        }
        #endregion
    }
}
