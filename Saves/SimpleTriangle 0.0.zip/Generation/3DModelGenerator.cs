﻿// Copyright (C) 2013, 2014 Alvarez Josué
//
// This code is free software; you can redistribute it and/or modify it
// under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation; either version 2.1 of the License, or (at
// your option) any later version.
//
// This code is distributed in the hope that it will be useful, but WITHOUT
// ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
// FITNESS FOR A PARTICULAR PURPOSE.  See the GNU Lesser General Public
// License (LICENSE.txt) for more details.
//
// You should have received a copy of the GNU Lesser General Public License
// along with this library; if not, write to the Free Software Foundation,
// Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
//
// The developer's email is jUNDERSCOREalvareATetudDOOOTinsa-toulouseDOOOTfr (for valid email, replace 
// capital letters by the corresponding character)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SlimDX;
using SlimDX.D3DCompiler;
using SlimDX.Direct3D11;
using SlimDX.DXGI;
using SlimDX.Windows;
using Device = SlimDX.Direct3D11.Device;
using Resource = SlimDX.Direct3D11.Resource;
using Vertex = SimpleTriangle.World.Graphics.VertexPositionTextureNormal.Vertex;
using System.Threading;
namespace SimpleTriangle.Generation
{

    /// <summary>
    /// Générateur de modèle 3D.
    /// </summary>
    public class ModelGenerator
    {
        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// Range : [0, 1]
        /// </summary>
        /// <param name="heightmap"></param>
        /// <returns></returns>
        public static void GenerateVertexBufferWithTransform2(float[,] heightmap, out SlimDX.Direct3D11.Buffer vBuffer,
            out SlimDX.Direct3D11.Buffer iBuffer, Matrix transform)
        {
            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1) ;


            // Création du vertex buffer contenant tous les vertex à dessiner.
            Vertex[] vertexBuffer = new Vertex[size];
            Noise.RidgedMultifractalNoise noise = new Noise.RidgedMultifractalNoise()
            {
                Frequency = 0.00400f,
                Lacunarity = 2.4f,
                OctaveCount = 2,
                Persistence = 0.9f,
                Quality = Noise.NoiseBase.NoiseQuality.QUALITY_FAST,
                Seed = 56549970
            };

            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    Vector4 pos = Vector4.Transform(new Vector4(x / ((float)heightmap.GetLength(0) - 1),
                                    (y / ((float)heightmap.GetLength(1) - 1)),
                                    heightmap[x, y],
                                    1.0f), transform);
                    vertexBuffer[(x + y * heightmap.GetLength(0))].Position = pos;
                    vertexBuffer[(x + y * heightmap.GetLength(0))].Texture = new Vector2(pos.X, pos.Y);


                    float texGen = noise.GetValue(pos.X, pos.Y, 0);
                    vertexBuffer[(x + y * heightmap.GetLength(0))].TextureId = texGen;
                }
                if(y % 5 == 0)
                    Thread.Sleep(1);
            }
            Thread.Sleep(1);
            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int iBufferSize = (heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6;
            int[] indexBuffer = new int[iBufferSize];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
                if (x % 5 == 0)
                    Thread.Sleep(1);
            }
            Thread.Sleep(1);
            // Calcule les normales aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal = new Vector4(0, 0, 0, 0);
            Thread.Sleep(1);
            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                Vector4 firstvec = vertexBuffer[indexBuffer[i * 3 + 1]].Position - vertexBuffer[indexBuffer[i * 3]].Position;
                Vector4 secondvec = vertexBuffer[indexBuffer[i * 3]].Position - vertexBuffer[indexBuffer[i * 3 + 2]].Position;
                Vector4 normal = new Vector4(Vector3.Cross(
                    new Vector3(firstvec.X, firstvec.Y, firstvec.Z),
                    new Vector3(secondvec.X, secondvec.Y, secondvec.Z)), 1.0f);
                normal.Normalize();
                vertexBuffer[indexBuffer[(i * 3)]].Normal += normal;
                vertexBuffer[indexBuffer[(i * 3 + 1)]].Normal += normal;
                vertexBuffer[indexBuffer[(i * 3 + 2)]].Normal += normal;

                if (i % 1000 == 0)
                    Thread.Sleep(1);
            }
            Thread.Sleep(1);
            for (int i = 0; i < vertexBuffer.Length; i++)
            {
                vertexBuffer[i].Normal.Z = vertexBuffer[i].Normal.Z;

                var v = Util.MathHelper.ReduceXYZ(vertexBuffer[i].Normal);
                v.Normalize();
                vertexBuffer[i].Normal = new Vector4(v, 1.0f);
            }
            Thread.Sleep(1);


            DataStream vBuffStream = new DataStream(size * Vertex.Stride, true, true);
            vBuffStream.WriteRange<Vertex>(vertexBuffer);
            vBuffStream.Position = 0;
            Thread.Sleep(1);
            DataStream iBuffStream = new DataStream(iBufferSize * sizeof(int), true, true);
            iBuffStream.WriteRange<int>(indexBuffer);
            iBuffStream.Position = 0;
            Thread.Sleep(1);
            vBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), vBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.VertexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)vBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            iBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), iBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.IndexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)iBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            vBuffStream.Dispose();
            iBuffStream.Dispose();
        }


        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// Range : [0, 1]
        /// </summary>
        /// <param name="heightmap"></param>
        /// <returns></returns>
        public static void GenerateVertexBufferWithTransform(float[,] heightmap, out SlimDX.Direct3D11.Buffer vBuffer,
            out SlimDX.Direct3D11.Buffer iBuffer, out InputElement[] layout, Matrix transform)
        {
            layout = new InputElement[] { new InputElement("POSITION", 0, Format.R32G32B32A32_Float, 0, 0),
                new InputElement("COLOR", 0, Format.R32G32B32A32_Float, 16, 0, InputClassification.PerVertexData, 0)
            };
            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1) * 2;


            // Création du vertex buffer contenant tous les vertex à dessiner.
            Vector4[] vertexBuffer = new Vector4[size];

            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    vertexBuffer[(x + y * heightmap.GetLength(0)) * 2] =
                        Vector4.Transform(new Vector4(x / ((float)heightmap.GetLength(0) - 1),
                                    (y / ((float)heightmap.GetLength(1) - 1)),
                                    heightmap[x, y],
                                    1.0f), transform);
                    vertexBuffer[(x + y * heightmap.GetLength(0)) * 2 + 1] = new Vector4(heightmap[x, y], 0, 0, 1);
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int iBufferSize = (heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6;
            int[] indexBuffer = new int[iBufferSize];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }

            // Calcule les normales aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length / 2; i++)
                vertexBuffer[(i * 2 + 1)] = new Vector4(0, 0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                int verticeId = (i * 3);
                Vector4 firstvec = vertexBuffer[indexBuffer[i * 3 + 1] * 2] - vertexBuffer[indexBuffer[i * 3] * 2];
                Vector4 secondvec = vertexBuffer[indexBuffer[i * 3] * 2] - vertexBuffer[indexBuffer[i * 3 + 2] * 2];
                Vector4 normal = new Vector4(Vector3.Cross(
                    new Vector3(firstvec.X, firstvec.Y, firstvec.Z),
                    new Vector3(secondvec.X, secondvec.Y, secondvec.Z)), 1.0f);
                normal.Normalize();
                vertexBuffer[indexBuffer[(i * 3)] * 2 + 1] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 1)] * 2 + 1] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 2)] * 2 + 1] += normal;
            }

            for (int i = 0; i < vertexBuffer.Length / 2; i++)
            {
                vertexBuffer[i * 2 + 1].Z = -vertexBuffer[i * 2 + 1].Z;

                var v = Util.MathHelper.ReduceXYZ(vertexBuffer[i * 2 + 1]);
                v.Normalize();
                vertexBuffer[i * 2 + 1] = new Vector4(v, 1.0f);
                vertexBuffer[i * 2 + 1].W = 1;
            }



            DataStream vBuffStream = new DataStream(size * sizeof(float) * 4, true, true);
            vBuffStream.WriteRange<Vector4>(vertexBuffer);
            vBuffStream.Position = 0;

            DataStream iBuffStream = new DataStream(iBufferSize * sizeof(int), true, true);
            iBuffStream.WriteRange<int>(indexBuffer);
            iBuffStream.Position = 0;

            vBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), vBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.VertexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)vBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            iBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), iBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.IndexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)iBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            vBuffStream.Dispose();
            iBuffStream.Dispose();
        }
        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// Range : [0, 1]
        /// </summary>
        /// <param name="heightmap"></param>
        /// <returns></returns>
        public static void GenerateVertexBuffer(float[,] heightmap, out SlimDX.Direct3D11.Buffer vBuffer, 
            out SlimDX.Direct3D11.Buffer iBuffer, out InputElement[] layout)
        {
            layout = new InputElement[] { new InputElement("POSITION", 0, Format.R32G32B32A32_Float, 0, 0),
                new InputElement("COLOR", 0, Format.R32G32B32A32_Float, 16, 0, InputClassification.PerVertexData, 0)
            };
            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1) * 2;


            // Création du vertex buffer contenant tous les vertex à dessiner.
            Vector4[] vertexBuffer = new Vector4[size];

            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    vertexBuffer[(x + y * heightmap.GetLength(0))*2] =
                        new Vector4(x / ((float)heightmap.GetLength(0)-1),
                                    (y / ((float)heightmap.GetLength(1)-1)),
                                    heightmap[x, y], 
                                    1.0f);
                    vertexBuffer[(x + y * heightmap.GetLength(0)) * 2 + 1] = new Vector4(heightmap[x, y], 0, 0, 1);
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int iBufferSize = (heightmap.GetLength(0) - 1)*(heightmap.GetLength(1) - 1)*6;
            int[] indexBuffer = new int[iBufferSize];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX-1; x++)
            {
                for (int y = 0; y < sizeY-1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;
                    
                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }

            // Calcule les normales aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length / 2; i++)
                vertexBuffer[(i * 2 + 1)] = new Vector4(0, 0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                int verticeId = (i * 3);
                Vector4 firstvec = vertexBuffer[indexBuffer[i * 3 + 1] * 2] - vertexBuffer[indexBuffer[i * 3] * 2];
                Vector4 secondvec = vertexBuffer[indexBuffer[i * 3] * 2] - vertexBuffer[indexBuffer[i * 3 + 2] * 2];
                Vector4 normal = new Vector4(Vector3.Cross(
                    new Vector3(firstvec.X, firstvec.Y, firstvec.Z),
                    new Vector3(secondvec.X, secondvec.Y, secondvec.Z)), 1.0f);
                normal.Normalize();
                vertexBuffer[indexBuffer[(i * 3)] * 2 + 1] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 1)] * 2 + 1] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 2)] * 2 + 1] += normal;
            }

            for (int i = 0; i < vertexBuffer.Length / 2; i++)
            {
                vertexBuffer[i * 2 + 1].Z = -vertexBuffer[i * 2 + 1].Z;
                
                var v = Util.MathHelper.ReduceXYZ(vertexBuffer[i * 2 + 1]);
                v.Normalize();
                vertexBuffer[i * 2 + 1] = new Vector4(v, 1.0f);
                vertexBuffer[i * 2 + 1].W = 1;
            }


            
            DataStream vBuffStream = new DataStream(size * sizeof(float) * 4, true, true);
            vBuffStream.WriteRange<Vector4>(vertexBuffer);
            vBuffStream.Position = 0;
            
            DataStream iBuffStream = new DataStream(iBufferSize * sizeof(int), true, true);
            iBuffStream.WriteRange<int>(indexBuffer);
            iBuffStream.Position = 0;

            vBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), vBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.VertexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)vBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            iBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), iBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.IndexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)iBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            vBuffStream.Dispose();
            iBuffStream.Dispose();
        }
        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// Range : [0, 1]
        /// </summary>
        /// <param name="heightmap"></param>
        /// <returns></returns>
        public static void GenerateVertexBufferPositionColorNormal(float[,] heightmap, out SlimDX.Direct3D11.Buffer vBuffer,
            out SlimDX.Direct3D11.Buffer iBuffer, out InputElement[] layout)
        {

            layout = new InputElement[] { new InputElement("POSITION", 0, Format.R32G32B32A32_Float, 0, 0),
                new InputElement("COLOR", 0, Format.R32G32B32A32_Float, 16, 0),
                new InputElement("NORMAL", 0, Format.R32G32B32A32_Float, 16, 0)
            };
            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1) * 3;


            // Création du vertex buffer contenant tous les vertex à dessiner.
            Vector4[] vertexBuffer = new Vector4[size];
            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    vertexBuffer[(x + y * heightmap.GetLength(0)) * 3] =
                        new Vector4(x / ((float)heightmap.GetLength(0) - 1.0f),
                                    y / ((float)heightmap.GetLength(1) - 1.0f),
                                    heightmap[x, y],
                                    1.0f);
                    vertexBuffer[(x + y * heightmap.GetLength(0)) * 3 + 1] =
                        new Vector4(x / ((float)heightmap.GetLength(0) - 1.0f),
                                    y / ((float)heightmap.GetLength(1) - 1.0f),
                                    heightmap[x, y],
                                    1.0f);
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int iBufferSize = (heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6;
            int[] indexBuffer = new int[iBufferSize];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }


            // Calcule les normales aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length / 3; i++)
                vertexBuffer[i * 3 + 2] = new Vector4(0, 0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                int verticeId = (i * 3);
                Vector4 firstvec = vertexBuffer[indexBuffer[i * 3 + 1] * 3] - vertexBuffer[indexBuffer[i * 3] * 3];
                Vector4 secondvec = vertexBuffer[indexBuffer[i * 3] * 3] - vertexBuffer[indexBuffer[i * 3 + 2] * 3];
                Vector4 normal = new Vector4(Vector3.Cross(
                    new Vector3(firstvec.X, firstvec.Y, firstvec.Z),
                    new Vector3(secondvec.X, secondvec.Y, secondvec.Z)), 0.0f);
                normal.Normalize();
                vertexBuffer[indexBuffer[(i * 3)] * 3 + 2] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 1)] * 3 + 2] += normal;
                vertexBuffer[indexBuffer[(i * 3 + 2)] * 3 + 2] += normal;
            }

            for (int i = 0; i < vertexBuffer.Length / 3; i++)
            {
                vertexBuffer[i * 3 + 2].Z = -vertexBuffer[i * 3 + 2].Z;
                vertexBuffer[i * 3 + 2].Normalize();
            }


            DataStream vBuffStream = new DataStream(size * sizeof(float) * 4, true, true);
            vBuffStream.WriteRange<Vector4>(vertexBuffer);
            vBuffStream.Position = 0;

            DataStream iBuffStream = new DataStream(iBufferSize * sizeof(int), true, true);
            iBuffStream.WriteRange<int>(indexBuffer);
            iBuffStream.Position = 0;

            vBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), vBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.VertexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)vBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            iBuffer = new SlimDX.Direct3D11.Buffer(Scene.GetGraphicsDevice(), iBuffStream, new BufferDescription()
            {
                BindFlags = BindFlags.IndexBuffer,
                CpuAccessFlags = CpuAccessFlags.None,
                OptionFlags = ResourceOptionFlags.None,
                SizeInBytes = (int)iBuffStream.Length,
                Usage = ResourceUsage.Default
            });

            vBuffStream.Dispose();
            iBuffStream.Dispose();
        }
        /*/// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <returns></returns>
        public static World.ModelData GenerateModel(float[,] heightmap, float hscale, float vscale = 1.0f, bool center = true, int quality=1)
        {
            return GenerateModel(heightmap, hscale, vscale, center, 0, 0, heightmap.GetLength(0) - 1, heightmap.GetLength(1) - 1, quality);
        }

        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// 
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <param name="texOffsetX">Offset des coordonées de texture selon X.</param>
        /// <param name="texOffsetY">Offset des coordonées de texture selon Y</param>
        /// <param name="texScaleX">Diviseur d'échelle horitontale des coordonnées de la texture</param>
        /// <param name="quality">Qualité du modèle : 1 qualité max. Au dessus de 1 : qualité de plus en plus grossière.</param>
        /// <returns></returns>
        public static List<World.ModelData> GenerateModel(int maxQuality, float[,] heightmap, float hscale, float vscale, bool center,
            float texOffsetX = 0.0f, float texOffsetY = 0.0f, float texScaleX = 1.0f, float texScaleY = 1.0f)
        {

            // Taille du buffer.
            List<World.ModelData> models = new List<World.ModelData>();
            int size = heightmap.GetLength(0) * heightmap.GetLength(1);


            // Création du vertex buffer contenant tous les vertex à dessiner.
            VertexPositionColorNormalTexture[] vertexBuffer = new VertexPositionColorNormalTexture[size];
            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    // Si center, on centre les vertices sur le point (0, 0).
                    Vector3 positionOffset = Vector3.Zero;
                    if (center)
                        positionOffset = new Vector3((x - heightmap.GetLength(0) / 2) * hscale,
                                    (y - heightmap.GetLength(1) / 2) * hscale,
                                    heightmap[x, y] * vscale);
                    else
                        positionOffset = new Vector3(x * hscale, y * hscale, heightmap[x, y] * vscale);

                    // Création du vertex.
                    vertexBuffer[x + y * heightmap.GetLength(0)] = new VertexPositionColorNormalTexture(
                        positionOffset,
                        Color.White,
                        new Vector3((x + texOffsetX) / texScaleX, (y + texOffsetY) / texScaleY, 0)
                        );
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            // Il permet de calculer les normales de manière précise.
            int[] indexBuffer = new int[(heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }


            // Calcule les normales aux surfaces.

            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal = new Vector3(0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                Vector3 firstvec = vertexBuffer[indexBuffer[i * 3 + 1]].Position - vertexBuffer[indexBuffer[i * 3]].Position;
                Vector3 secondvec = vertexBuffer[indexBuffer[i * 3]].Position - vertexBuffer[indexBuffer[i * 3 + 2]].Position;
                Vector3 normal = Vector3.Cross(firstvec, secondvec);
                normal.Normalize();
                vertexBuffer[indexBuffer[i * 3]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 1]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 2]].Normal += normal;
            }
            for (int i = 0; i < vertexBuffer.Length; i++)
            {
                vertexBuffer[i].Normal.Z = -vertexBuffer[i].Normal.Z;
                vertexBuffer[i].Normal.Normalize();
            }



            // Crée finalement les vertex et index buffers et les assigne à un modèle.
            var vertices = new VertexBuffer(Game1.Instance.GraphicsDevice, VertexPositionColorNormalTexture.VertexDeclaration, size, BufferUsage.None);
            vertices.SetData<VertexPositionColorNormalTexture>(vertexBuffer);
            var indices = new IndexBuffer(Game1.Instance.GraphicsDevice, IndexElementSize.ThirtyTwoBits, indexBuffer.Count(), BufferUsage.None);
            indices.SetData<int>(indexBuffer);

            // Si la qualité max est incluse, on l'ajoute aux modèles.
            models.Add(new World.ModelData(vertices, indices));

            // Crée les index buffer des qualités inférieures.
            int quality = 2;
            int[] lastBuffer = indexBuffer;
            while (quality <= maxQuality)
            {
                int div = (int)Math.Pow(2, quality-1);
                lastBuffer = GetSubdividedIndexBuffer(indexBuffer, heightmap.GetLength(0), heightmap.GetLength(1), div);
                // Crée et ajoute les indices subdivisés.
                IndexBuffer indicesMipmap = new IndexBuffer(Game1.Instance.GraphicsDevice, IndexElementSize.ThirtyTwoBits, lastBuffer.Count(), BufferUsage.None);
                indicesMipmap.SetData<int>(lastBuffer);
                models.Add(new World.ModelData(vertices, indicesMipmap));
                quality++;
            }

            return models;
        }

        /// <summary>
        /// Crée et retourne une version de qualité divisée par deux de l'index buffer.
        /// </summary>
        /// <param name="indexBuffer"></param>
        /// <returns></returns>
        static int[] GetSubdividedIndexBuffer(int[] indexBufferSrc, int width, int height, int div)
        {
            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            // Il permet de calculer les normales de manière précise.
            
            int sizeX = width/div;
            int sizeY = height/div;
            int[] indexBuffer = new int[sizeX * sizeY * 6];
            int startIndex = 0;
            for (int x = 0; x < sizeX; x++)
            {
                for (int y = 0; y < sizeY; y++)
                {
                    int firstIndex = x*div + y * width * div;
                    int topLeft = firstIndex;
                    int topRight = firstIndex + div;
                    int lowerLeft = topLeft + div*width;
                    int lowerRight = lowerLeft + div;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }
            return indexBuffer;
        }

        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <param name="texOffsetX">Offset des coordonées de texture selon X.</param>
        /// <param name="texOffsetY">Offset des coordonées de texture selon Y</param>
        /// <param name="texScaleX">Diviseur d'échelle horitontale des coordonnées de la texture</param>
        /// <param name="quality">Qualité du modèle : 1 qualité max. Au dessus de 1 : qualité de plus en plus grossière.</param>
        /// <returns></returns>
        public static World.ModelData GenerateModel(float[,] heightmap, float hscale, float vscale, bool center,
            float texOffsetX = 0.0f, float texOffsetY = 0.0f, float texScaleX = 1.0f, float texScaleY = 1.0f, int quality = 1)
        {
            if (quality != 1)
            {
                hscale *= quality;
                texOffsetX /= quality;
                texOffsetY /= quality;
                texScaleX /= quality;
                texScaleY /= quality;
                heightmap = CopyArea(heightmap, quality);
            }


            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1);


            // Création du vertex buffer contenant tous les vertex à dessiner.
            VertexPositionColorNormalTexture[] vertexBuffer = new VertexPositionColorNormalTexture[size];
            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    // Si center, on centre les vertices sur le point (0, 0).
                    Vector3 positionOffset = Vector3.Zero;
                    if (center)
                        positionOffset = new Vector3((x - heightmap.GetLength(0) / 2) * hscale,
                                    (y - heightmap.GetLength(1) / 2) * hscale,
                                    heightmap[x, y] * vscale);
                    else
                        positionOffset = new Vector3(x * hscale, y * hscale, heightmap[x, y] * vscale);

                    // Création du vertex.
                    vertexBuffer[x + y * heightmap.GetLength(0)] = new VertexPositionColorNormalTexture(
                        positionOffset,
                        Color.White,
                        new Vector3((x + texOffsetX) / texScaleX, (y + texOffsetY) / texScaleY, 0)
                        );
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int[] indexBuffer = new int[(heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }


            // Calcule les normals aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal = new Vector3(0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                Vector3 firstvec = vertexBuffer[indexBuffer[i * 3 + 1]].Position - vertexBuffer[indexBuffer[i * 3]].Position;
                Vector3 secondvec = vertexBuffer[indexBuffer[i * 3]].Position - vertexBuffer[indexBuffer[i * 3 + 2]].Position;
                Vector3 normal = Vector3.Cross(firstvec, secondvec);
                normal.Normalize();
                vertexBuffer[indexBuffer[i * 3]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 1]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 2]].Normal += normal;
            }
            for (int i = 0; i < vertexBuffer.Length; i++)
            {
                vertexBuffer[i].Normal.Z = -vertexBuffer[i].Normal.Z;
                vertexBuffer[i].Normal.Normalize();
            }


            // Crée finalement les vertex et index buffers et les assigne à un modèle.
            var vertices = new VertexBuffer(Game1.Instance.GraphicsDevice, VertexPositionColorNormalTexture.VertexDeclaration, size, BufferUsage.None);
            vertices.SetData<VertexPositionColorNormalTexture>(vertexBuffer);
            var indices = new IndexBuffer(Game1.Instance.GraphicsDevice, IndexElementSize.ThirtyTwoBits, indexBuffer.Count(), BufferUsage.None);
            indices.SetData<int>(indexBuffer);

            World.ModelData model = new World.ModelData(vertices, indices);
            return model;
        }

        #region Vertical
        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <returns></returns>
        public static World.ModelData GenerateModelV(float[,] heightmap, float hscale, float vscale = 1.0f, bool center = true, int quality = 1)
        {
            return GenerateModelV(heightmap, hscale, vscale, center, 0, 0, heightmap.GetLength(0) - 1, heightmap.GetLength(1) - 1, quality);
        }

        /// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <param name="texOffsetX">Offset des coordonées de texture selon X.</param>
        /// <param name="texOffsetY">Offset des coordonées de texture selon Y</param>
        /// <param name="texScaleX">Diviseur d'échelle horitontale des coordonnées de la texture</param>
        /// <param name="quality">Qualité du modèle : 1 qualité max. Au dessus de 1 : qualité de plus en plus grossière.</param>
        /// <returns></returns>
        public static World.ModelData GenerateModelV(float[,] heightmap, float hscale, float vscale, bool center,
            float texOffsetX = 0.0f, float texOffsetY = 0.0f, float texScaleX = 1.0f, float texScaleY = 1.0f, int quality = 1)
        {
            if (quality != 1)
            {
                hscale *= quality;
                texOffsetX /= quality;
                texOffsetY /= quality;
                texScaleX /= quality;
                texScaleY /= quality;
                heightmap = CopyArea(heightmap, quality);
            }


            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1);


            // Création du vertex buffer contenant tous les vertex à dessiner.
            VertexPositionColorNormalTexture[] vertexBuffer = new VertexPositionColorNormalTexture[size];
            for (int y = 0; y < heightmap.GetLength(1); y++)
            {
                for (int x = 0; x < heightmap.GetLength(0); x++)
                {
                    // Si center, on centre les vertices sur le point (0, 0).
                    Vector3 positionOffset = Vector3.Zero;
                    if (center)
                        positionOffset = new Vector3(
                                    x  * hscale,
                                    heightmap[x, y] * vscale,
                                    -y * hscale
                                    );
                    else
                        positionOffset = new Vector3(x * hscale, heightmap[x, y] * vscale, y * hscale);

                    // Création du vertex.
                    vertexBuffer[x + y * heightmap.GetLength(0)] = new VertexPositionColorNormalTexture(
                        positionOffset,
                        Color.White,
                        new Vector3((x + texOffsetX) / texScaleX, (y + texOffsetY) / texScaleY, 0)
                        );
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int[] indexBuffer = new int[(heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < sizeX - 1; x++)
            {
                for (int y = 0; y < sizeY - 1; y++)
                {
                    int firstIndex = x + y * (sizeX);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }


            // Calcule les normals aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal = new Vector3(0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                Vector3 firstvec = vertexBuffer[indexBuffer[i * 3 + 1]].Position - vertexBuffer[indexBuffer[i * 3]].Position;
                Vector3 secondvec = vertexBuffer[indexBuffer[i * 3]].Position - vertexBuffer[indexBuffer[i * 3 + 2]].Position;
                Vector3 normal = Vector3.Cross(firstvec, secondvec);
                normal.Normalize();
                vertexBuffer[indexBuffer[i * 3]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 1]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 2]].Normal += normal;
            }
            for (int i = 0; i < vertexBuffer.Length; i++)
            {
                vertexBuffer[i].Normal.Z = -vertexBuffer[i].Normal.Z;
                vertexBuffer[i].Normal.Normalize();
            }



            // Crée finalement les vertex et index buffers et les assigne à un modèle.
            var vertices = new VertexBuffer(Game1.Instance.GraphicsDevice, VertexPositionColorNormalTexture.VertexDeclaration, size, BufferUsage.None);
            vertices.SetData<VertexPositionColorNormalTexture>(vertexBuffer);
            var indices = new IndexBuffer(Game1.Instance.GraphicsDevice, IndexElementSize.ThirtyTwoBits, indexBuffer.Count(), BufferUsage.None);
            indices.SetData<int>(indexBuffer);

            World.ModelData model = new World.ModelData(vertices, indices);
            return model;
        }
        #endregion
        /// <summary>
        /// Crée et retourne une copie de la partie définie par le Rectangle area de la heightmap donnée.
        /// </summary>
        /// <param name="heightmap"></param>
        /// <param name="area"></param>
        /// <returns></returns>
        static float[,] CopyArea(float[,] heightmap, int quality)
        {
            int w = heightmap.GetLength(0) / quality;
            int h = heightmap.GetLength(1) / quality;
            float[,] subMap = new float[w+1, h+1];
            for (int x = 0; x < w; x++)
            {
                for (int y = 0; y < h; y++)
                {
                    subMap[x, y] = heightmap[x*quality, y*quality];
                }
            }

            // Pour que les frontières soient exactement les mêmes que la version en + grande qualité :
            for (int x = 0; x < w + 1; x++)
                subMap[x, h] = heightmap[x*quality, heightmap.GetLength(1) - 1];
            for (int y = 0; y < h + 1; y++)
                subMap[w, y] = heightmap[heightmap.GetLength(0) - 1, y*quality];

            return subMap;
        }*/

        /*/// <summary>
        /// Génère un modèle 3D à partir d'une heightmap.
        /// </summary>
        /// <param name="heightmap">La heightmap</param>
        /// <param name="hscale">Ajustement de l'échelle horizontale.</param>
        /// <param name="vscale">Ajustement de l'échelle verticale.</param>
        /// <param name="center">Si vrai, les coordonnées des vertex du modèles seront centrées en (0, 0)</param>
        /// <param name="texOffsetX">Offset des coordonées de texture selon X.</param>
        /// <param name="texOffsetY">Offset des coordonées de texture selon Y</param>
        /// <param name="texScaleX">Diviseur d'échelle horitontale des coordonnées de la texture</param>
        /// <param name="quality">Qualité du modèle : 1 qualité max. Au dessus de 1 : qualité de plus en plus grossière.</param>
        /// <returns></returns>
        public static World.ModelData GenerateModel(float[,] heightmap, float hscale, float vscale, bool center, 
            float texOffsetX=0.0f, float texOffsetY=0.0f, float texScaleX=1.0f, float texScaleY=1.0f, int quality=2)
        {

            // Taille du buffer.
            int size = heightmap.GetLength(0) * heightmap.GetLength(1) / quality;
            int ly = heightmap.GetLength(1) - heightmap.GetLength(1) % quality;
            int lx = heightmap.GetLength(0) - heightmap.GetLength(0) % quality;

            // Création du vertex buffer contenant tous les vertex à dessiner.
            VertexPositionColorNormalTexture[] vertexBuffer = new VertexPositionColorNormalTexture[size];
            int vbufferIndex = 0;
            for (int y = 0; y < ly; y+=quality)
            {
                for (int x = 0; x < lx; x+=quality)
                {
                    // Si center, on centre les vertices sur le point (0, 0).
                    Vector3 positionOffset = Vector3.Zero;
                    if (center)
                        positionOffset = new Vector3((x - heightmap.GetLength(0) / 2) * hscale,
                                    (y - heightmap.GetLength(1) / 2) * hscale,
                                    heightmap[x, y] * vscale);
                    else
                        positionOffset = new Vector3(x * hscale, y * hscale, heightmap[x, y] * vscale);

                    // Création du vertex.
                    vertexBuffer[vbufferIndex] = new VertexPositionColorNormalTexture(
                        positionOffset,
                        Color.White,
                        new Vector3((x+texOffsetX) / texScaleX, (y+texOffsetY) / texScaleY, 0)
                        );

                    vbufferIndex++;
                }
            }

            // Index buffer contenant l'ordre dans lequel dessiner les vertex. (sous forme de carrés).
            int qualitySqr = quality * quality;
            int[] indexBuffer = new int[(heightmap.GetLength(0) - 1) * (heightmap.GetLength(1) - 1) * 6 / qualitySqr];
            int sizeX = heightmap.GetLength(0);
            int sizeY = heightmap.GetLength(1);
            int startIndex = 0;
            for (int x = 0; x < (sizeX - 1)/quality; x++)
            {
                for (int y = 0; y < (sizeY - 1)/quality; y++)
                {
                    int firstIndex = x + y * (sizeX/quality);
                    int topLeft = firstIndex;
                    int topRight = firstIndex + 1;
                    int lowerLeft = topLeft + sizeX/quality;
                    int lowerRight = lowerLeft + 1;
                    // Triangle 1 (up right)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = lowerRight;
                    indexBuffer[startIndex++] = lowerLeft;

                    // Triangle 2 (bottom left)
                    indexBuffer[startIndex++] = topLeft;
                    indexBuffer[startIndex++] = topRight;
                    indexBuffer[startIndex++] = lowerRight;
                }
            }


            // Calcule les normals aux surfaces.
            // Merci Riemer's XNA Tutorial :D
            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal = new Vector3(0, 0, 0);

            for (int i = 0; i < indexBuffer.Length / 3; i++)
            {
                Vector3 firstvec = vertexBuffer[indexBuffer[i * 3 + 1]].Position - vertexBuffer[indexBuffer[i * 3]].Position;
                Vector3 secondvec = vertexBuffer[indexBuffer[i * 3]].Position - vertexBuffer[indexBuffer[i * 3 + 2]].Position;
                Vector3 normal = Vector3.Cross(firstvec, secondvec);
                normal.Normalize();
                vertexBuffer[indexBuffer[i * 3]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 1]].Normal += normal;
                vertexBuffer[indexBuffer[i * 3 + 2]].Normal += normal;
            }
            for (int i = 0; i < vertexBuffer.Length; i++)
                vertexBuffer[i].Normal.Normalize();



            // Crée finalement les vertex et index buffers et les assigne à un modèle.
            var vertices = new VertexBuffer(Game1.Instance.GraphicsDevice, VertexPositionColorNormalTexture.VertexDeclaration, size, BufferUsage.None);
            vertices.SetData<VertexPositionColorNormalTexture>(vertexBuffer);
            var indices = new IndexBuffer(Game1.Instance.GraphicsDevice, IndexElementSize.ThirtyTwoBits, indexBuffer.Count(), BufferUsage.None);
            indices.SetData<int>(indexBuffer);

            World.ModelData model = new World.ModelData(vertices, indices);
            return model;
        }
        */


    }
}
