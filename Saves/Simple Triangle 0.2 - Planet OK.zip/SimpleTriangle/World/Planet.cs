﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using SlimDX;
using SlimDX.D3DCompiler;
using SlimDX.Direct3D11;
using SlimDX.DXGI;
using SlimDX.Windows;
using Device = SlimDX.Direct3D11.Device;
using Resource = SlimDX.Direct3D11.Resource;
namespace SimpleTriangle.World
{
    /// <summary>
    /// Représente une planète.
    /// </summary>
    public class Planet
    {
        #region Variables
        PlanetCell m_planet;
        QuadTreeCell m_mainCell;
        #endregion

        #region Methods
        /// <summary>
        /// Crée une nouvelle instance de Planet.
        /// </summary>
        public Planet()
        {
            LoadGraphics();
            // m_planet = new PlanetCell(Vector3.Zero, new Vector2(0, 0), 1.0f, new Vector3(40000, 40000, -20f), 45087027, false, 0);

            m_mainCell = new QuadTreeCell(Vector3.Zero, new Vector2(0, 0), 1.0f, new Vector3(40000, 40000, -20f), 45087027, 0, 50000);
            m_mainCell.Ressources.Add(new TerrainRessource(m_mainCell));
            m_mainCell.Ressources.Add(new WaterRessource(m_mainCell));
            m_mainCell.InitializeRessources();
        }

        /// <summary>
        /// Charge les ressources graphiques associées à cet objet.
        /// </summary>
        public void LoadGraphics()
        {
           
          
        }
        /// <summary>
        /// Mets à jour la planète.
        /// </summary>
        public void Update(GameTime time)
        {
            //m_planet.Update();
            m_mainCell.Update(time);
        }


        float test = 0.0f;
        /// <summary>
        /// Dessine la planète.
        /// </summary>
        public void Draw()
        {
            //m_planet.Draw();
            m_mainCell.Draw();
        }
        /// <summary>
        /// Libère les ressources non managées allouées par cet objet.
        /// </summary>
        public void Dispose()
        {
            m_mainCell.Dispose();
        }
        #endregion
    }
}
